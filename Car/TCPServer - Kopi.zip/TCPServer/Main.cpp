#include "TCP.h"
int main()
{


TCP funktioner;
string besked;
//int comande;
//bool tilstand;
//funktioner.TCP(argv[1]);
//funktioner.start();

TCP TCP; 


while(1)
{
//cout<<"intast"<<endl;
//cin>>besked;
//funktioner.writeText(besked);
//
//
}


}