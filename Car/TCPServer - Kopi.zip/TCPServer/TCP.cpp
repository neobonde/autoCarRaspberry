#include "TCP.h"

TCP::TCP(int port){
//statusIn_ = 0;
//statusOut_ = 0;
string command;
  portno = port;
  
  cout << "Setting up TCP server" << endl << "port: " << portno << endl; 

  sockWel = socket(AF_INET, SOCK_STREAM, 0);
  if(sockWel < 0){
    cout << "Error opening socket" << endl;
  }
  
  cout << "Socket opened" << endl;

  int enable = 1;
  if (setsockopt(sockWel, SOL_SOCKET, SO_REUSEADDR, &enable, sizeof(int)) < 0)
	  cout << "Error set sock opt" << endl;
 
  cout << "sock opt set" << endl;
  bzero((char *) &serv_addr, sizeof(serv_addr));
  serv_addr.sin_family = AF_INET;
  serv_addr.sin_addr.s_addr = INADDR_ANY;
  serv_addr.sin_port = htons(portno);

  if (bind(sockWel, (struct sockaddr *) &serv_addr, sizeof(serv_addr)) < 0)
  {
	  cout << "Error on binding" << endl;
  }
  cout << "Binded" << endl;
  waitForConnection();

}

void *TCP::waitForConnection(void){
  // Listening
  cout << "Looking for clients..." << endl;
cout<<"1"<<endl;
  listen(sockWel, 5);
cout<<"1"<<endl;
  size = sizeof(cli_addr);

  sockNew = accept(sockWel, (struct sockaddr *) &cli_addr, &size);
  if (sockNew < 0)
  {
	  cout << "Error on accept" << endl;
  }
  
  cout << "Client Connected" << endl;


  while(1)
  {

	listen(sockNew, 5);
    command = readTextTCP(command, sockNew);
    //statusIn_ = 1;
    //do{
    //usleep(1);
    //}while(statusOut_!= 0);
cout<<command<<endl;
command.clear();
cout << "intast" << endl;
cin>>command;
    writeTextTCP(command, sockNew);
command.clear();
  }

  close(sockNew);
  return 0;
}

//void *TCP::threadWrapper(void* arg){
	//return ((TCP *)arg)->waitForConnection();

//}

//string TCP::getCmd(){
//	string tmp = command;
//	command.clear();	
//	return tmp;
//}
//
//void TCP::setCmd(string cmd){
//	writeTextTCP(cmd,sockNew);
//}

//bool TCP::getInStatus(){
//
//	return(statusIn_);
//
//	}


//void changeOutStatus(bool Status){
//	if (Status == 0){
//	return 0
//	}
//	else{
//	statusOut_= 1;
//	statusIn_ = 0;
//	return 0;
//	}
//
//
//	}


//void comandToSend(string comandToSend){
//	command = comandToSend;

//	}



const string TCP::readTextTCP(string inText, int inFromServer)
{
    char ch;

    read(inFromServer, &ch, 1);
    while(ch != 0)
    {
   		inText += ch;
        read(inFromServer, &ch, 1);
    }
    return inText;
}

/**
 * Skriver en tekststreng til en socket med 0 terminering
 *
 * @param outToServer Stream hvortil der skrives data til socket
 * @param line Teksten der skal skrives til socket
 */
void TCP::writeTextTCP(string line, int outToServer)
{
	write(outToServer, line.c_str(), line.length());
	write(outToServer, "\0", 1);
}


